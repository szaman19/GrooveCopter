import requests

emotions = ["anger", "contempt", "disgust", "fear",
            "happiness", "neutral", "sadness", "surprise"]
emotionsDict = {}
for emotion in emotions:
    emotionsDict[emotion] = 0.0

headers = {
    # Request headers
    'Content-Type': 'application/octet-stream',
    'Ocp-Apim-Subscription-Key': '704a50957cb5458f927313db05da8391',}

body =  open("joffrey.jpg",'rb').read()

request = requests.post("https://api.projectoxford.ai/emotion/v1.0/recognize",
                  headers=headers,data=body)
values = request.json()
for info in values:
    scores = info[unicode('scores')]
    keys = scores.keys()
    for key in keys:
        emotionsDict[str(key)] = emotionsDict[str(key)] + round(scores[key], 3)
music = []
for emotion in emotions:
    if(emotionsDict[emotion] / len(values) > 0.2):
        music.append(emotion)
print(music)
