(function(window, document) {

        var Snap = function Snap(cockpit) {
            console.log("Initializing snap plugin.");
            this.cockpit = cockpit;

            // Add some UI elements
            $('#cockpit').append('<img id="snap" style = "visibility:hidden;"src="" />');

            // Update image at 20fps
            var videoImg = $("#snap");
            var canvas = videoImg;
            //var image = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream");  // here is the most important part because if you dont replace you will get a DOM 18 exception.
            //window.location.href=image;
            videoImg.attr("src", '/camera/' + new Date().getTime());


            setInterval(function() {
                videoImg.attr("src", '/camera/' + new Date().getTime());
            }, 500);
        };

        window.Cockpit.plugins.push(Snap);
}(window, document));
